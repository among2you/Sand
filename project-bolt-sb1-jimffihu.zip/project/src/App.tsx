import React, { useEffect, useRef, useState } from 'react';
import { Eraser, Pipette, Square } from 'lucide-react';
import { Materials, MaterialType, initializeGrid, updateGrid } from './game/materials';
import { MaterialPalette } from './components/MaterialPalette';
import { Toolbar } from './components/Toolbar';

const CANVAS_WIDTH = 800;
const CANVAS_HEIGHT = 600;
const PIXEL_SIZE = 4;
const GRID_WIDTH = CANVAS_WIDTH / PIXEL_SIZE;
const GRID_HEIGHT = CANVAS_HEIGHT / PIXEL_SIZE;

function App() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [grid, setGrid] = useState(() => initializeGrid(GRID_WIDTH, GRID_HEIGHT));
  const [selectedMaterial, setSelectedMaterial] = useState<MaterialType>('sand');
  const [tool, setTool] = useState<'draw' | 'erase' | 'picker'>('draw');
  const [isDrawing, setIsDrawing] = useState(false);
  
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationFrameId: number;
    
    const render = () => {
      ctx.fillStyle = '#000';
      ctx.fillRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);
      
      for (let y = 0; y < GRID_HEIGHT; y++) {
        for (let x = 0; x < GRID_WIDTH; x++) {
          const material = grid[y][x];
          if (material !== 'empty') {
            ctx.fillStyle = Materials[material].color;
            ctx.fillRect(x * PIXEL_SIZE, y * PIXEL_SIZE, PIXEL_SIZE, PIXEL_SIZE);
          }
        }
      }
      
      setGrid(prevGrid => updateGrid(prevGrid));
      animationFrameId = requestAnimationFrame(render);
    };
    
    render();
    return () => cancelAnimationFrame(animationFrameId);
  }, [grid]);

  const handleCanvasInteraction = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const rect = canvas.getBoundingClientRect();
    const x = Math.floor((e.clientX - rect.left) / PIXEL_SIZE);
    const y = Math.floor((e.clientY - rect.top) / PIXEL_SIZE);

    if (x < 0 || x >= GRID_WIDTH || y < 0 || y >= GRID_HEIGHT) return;

    if (tool === 'picker') {
      const pickedMaterial = grid[y][x];
      if (pickedMaterial !== 'empty') {
        setSelectedMaterial(pickedMaterial);
        setTool('draw');
      }
      return;
    }

    setGrid(prevGrid => {
      const newGrid = [...prevGrid.map(row => [...row])];
      const radius = 2;
      
      for (let dy = -radius; dy <= radius; dy++) {
        for (let dx = -radius; dx <= radius; dx++) {
          const newX = x + dx;
          const newY = y + dy;
          
          if (
            newX >= 0 && 
            newX < GRID_WIDTH && 
            newY >= 0 && 
            newY < GRID_HEIGHT &&
            dx * dx + dy * dy <= radius * radius
          ) {
            newGrid[newY][newX] = tool === 'draw' ? selectedMaterial : 'empty';
          }
        }
      }
      
      return newGrid;
    });
  };

  return (
    <div className="min-h-screen bg-gray-900 flex flex-col items-center justify-center gap-4 p-4">
      <div className="flex gap-4 items-start">
        <div className="bg-gray-800 p-4 rounded-lg">
          <canvas
            ref={canvasRef}
            width={CANVAS_WIDTH}
            height={CANVAS_HEIGHT}
            className="border-2 border-gray-700 rounded cursor-crosshair"
            onMouseDown={(e) => {
              setIsDrawing(true);
              handleCanvasInteraction(e);
            }}
            onMouseUp={() => setIsDrawing(false)}
            onMouseMove={(e) => isDrawing && handleCanvasInteraction(e)}
            onMouseLeave={() => setIsDrawing(false)}
          />
        </div>
        
        <div className="flex flex-col gap-4">
          <Toolbar
            tool={tool}
            onToolChange={setTool}
            tools={[
              { id: 'draw', icon: Square, label: 'Draw' },
              { id: 'erase', icon: Eraser, label: 'Erase' },
              { id: 'picker', icon: Pipette, label: 'Picker' }
            ]}
          />
          
          <MaterialPalette
            selectedMaterial={selectedMaterial}
            onSelectMaterial={setSelectedMaterial}
          />
        </div>
      </div>
    </div>
  );
}

export default App;