import React from 'react';
import { DivideIcon as LucideIcon } from 'lucide-react';

interface ToolbarProps {
  tool: string;
  tools: {
    id: string;
    icon: LucideIcon;
    label: string;
  }[];
  onToolChange: (tool: any) => void;
}

export function Toolbar({ tool, tools, onToolChange }: ToolbarProps) {
  return (
    <div className="bg-gray-800 p-4 rounded-lg">
      <h2 className="text-white text-lg font-bold mb-3">Tools</h2>
      <div className="flex flex-col gap-2">
        {tools.map(({ id, icon: Icon, label }) => (
          <button
            key={id}
            className={`flex items-center gap-2 px-3 py-2 rounded transition-all ${
              tool === id
                ? 'bg-blue-500 text-white'
                : 'bg-gray-700 text-gray-300 hover:bg-gray-600'
            }`}
            onClick={() => onToolChange(id)}
          >
            <Icon size={18} />
            <span className="text-sm">{label}</span>
          </button>
        ))}
      </div>
    </div>
  );
}