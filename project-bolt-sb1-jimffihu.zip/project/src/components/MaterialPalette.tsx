import React from 'react';
import { Materials, MaterialType } from '../game/materials';

interface MaterialPaletteProps {
  selectedMaterial: MaterialType;
  onSelectMaterial: (material: MaterialType) => void;
}

export function MaterialPalette({ selectedMaterial, onSelectMaterial }: MaterialPaletteProps) {
  return (
    <div className="bg-gray-800 p-4 rounded-lg">
      <h2 className="text-white text-lg font-bold mb-3">Materials</h2>
      <div className="grid grid-cols-2 gap-2">
        {Object.entries(Materials).map(([id, material]) => (
          <button
            key={id}
            className={`p-2 rounded transition-all ${
              selectedMaterial === id
                ? 'ring-2 ring-blue-500 scale-105'
                : 'hover:scale-105'
            }`}
            style={{ backgroundColor: material.color }}
            onClick={() => onSelectMaterial(id as MaterialType)}
          >
            <span className="text-xs font-bold text-white drop-shadow-[0_1px_1px_rgba(0,0,0,0.8)]">
              {material.name}
            </span>
          </button>
        ))}
      </div>
    </div>
  );
}